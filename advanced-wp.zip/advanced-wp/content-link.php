<article class="post post-link">
<div class="well">
	<small>
		<a href="<?php echo get_the_content(); ?>"><?php echo the_title(); ?></a>
	</small>

</div>
</article>